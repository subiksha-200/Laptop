package com.review.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.review.demo.model.Employee;
import com.review.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository empRepository;
	
	public List<Employee> getAllEmployees()
	{
		List<Employee> emplist=empRepository.findAll();
		return emplist;
	}
	public Employee saveEmployee(Employee s)
	{
		return empRepository.save(s);
	}
	public Employee deleteEmployee(int age)
	{
		empRepository.deleteById(age);
		return null;
	}
}
