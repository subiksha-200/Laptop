package com.myproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.demo.model.student;
import com.myproject.demo.repository.studentrep;

@Service
public class studentService {
	@Autowired
	studentrep studRepository;
	
	public List<student> getAllStudents()
	{
		List<student> studList=studRepository.findAll();
		return studList;
	}
	
	public student saveStudent (student s)
	{
		return studRepository.save(s);
	}

	public student deleteStudent(int rollno)
	{
		studRepository.deleteById(rollno);
		return null;
	}
	public student getStudent(int rollno) {
		return studRepository.findById(rollno).get();
	}
}
