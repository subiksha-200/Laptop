package com.myproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.demo.model.student;
import com.myproject.demo.service.studentService;

@RestController
public class studentController {
	@Autowired
	studentService studService;
	@GetMapping(value="/fetchStudents")
	public List<student> getAllStudents()
	{
		List<student> studList=studService.getAllStudents();
		return studList;
	}
	@PostMapping(value="/saveStudents")
	public student saveStudent(@RequestBody student s) 
	{
		return studService.saveStudent(s);
	}
	
	@PutMapping(value="/updateStudents")
	public student updateStudent(@RequestBody student s)
	{
		return studService.saveStudent(s);
	}
	@DeleteMapping("/deleStudents/{rno}")
	public void deleteStudent(@PathVariable("rno") int rollno)
	{
		 studService.deleteStudent(rollno);
	}
	@GetMapping(value="/getStudents/{rno}")
	public student getStudent(@PathVariable("rno") int rollno)
	{
		return studService.getStudent(rollno);
	}
}
