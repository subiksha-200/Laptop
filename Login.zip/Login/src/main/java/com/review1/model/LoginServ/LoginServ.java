package com.review1.model.LoginServ;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.review1.model.Model.Login;
import com.review1.model.Repository.Loginrepo;

@Service
public class LoginServ {
	@Autowired
	public Loginrepo lr;
	public String checkLogin(String username,String password)
	{
		Login ss=lr.findByusername(username);
		if(ss==null)
		{
			return "no user found";
		}
		else
		{
			if(ss.getPassword().equals(password))
			{
				return "Login Successfull";
			}
			else
			{
				return "Login failed";
			}
		}
	}
	public Login AddUser(Login n) {
		return lr.save(n);
	}
	public List<Login> getUser()
	{
		return lr.findAll();
	}
	public List<Login>sortDetail(String id)
	{
		return lr.findAll(Sort.by(id).descending());
	}
	public List<Login> pagination(int id,int id1)
	{
		Page<Login> p=lr.findAll(PageRequest.of(id, id1));
		return p.getContent(); 
	}
	public List<Login> pagination1(int id,int id1,String name)
	{
		Page<Login> p=lr.findAll(PageRequest.of(id, id1,Sort.by(name).ascending()));
		return p.getContent();
	}
}
