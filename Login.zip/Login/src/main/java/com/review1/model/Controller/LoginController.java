package com.review1.model.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.review1.model.LoginServ.LoginServ;
import com.review1.model.Model.Login;

@RestController
@RequestMapping("/detail")
public class LoginController {
@Autowired
private LoginServ ls;
@PostMapping("/Login")
public String Logincheck(@RequestBody Map<String, String>Logindata)
{
	String username=Logindata.get("username");
	String password=Logindata.get("password");
	String result=ls.checkLogin(username, password);
	return result;
}
@PostMapping("/adddetail")
public Login  AddUser(@RequestBody Login Login)
{
	return ls.AddUser(Login);
}
@GetMapping
	public List<Login> Listall()
	{
		return ls.getUser();
			}
@GetMapping("/sortdetail/{id}")
public List<Login> sortid(@PathVariable String id)
{
	return ls.sortDetail(id);
}
@GetMapping("/getbypage/{id}/{id1}")
public List<Login> getbypagination(@PathVariable("id") int id,@PathVariable("id1")int id1)
{
	return ls.pagination(id,id1);
}
@GetMapping("/pagesort/{id}/{id1}/{name}")
public List<Login> getbypagination1(@PathVariable("id") int id,@PathVariable("id1") int id1,@PathVariable("name") String n)
{
	return ls.pagination1(id,id1,n);
}
{
	
}
}
