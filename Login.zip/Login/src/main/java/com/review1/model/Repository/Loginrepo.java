package com.review1.model.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.review1.model.Model.Login;

public interface Loginrepo extends JpaRepository<Login, Integer> {
	Login findByusername(String username);

}
