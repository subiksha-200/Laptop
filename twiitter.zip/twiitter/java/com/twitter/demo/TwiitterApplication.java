package com.twitter.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwiitterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwiitterApplication.class, args);
	}

}
