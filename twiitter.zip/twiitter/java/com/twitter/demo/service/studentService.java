package com.twitter.demo.service;

import org.springframework.stereotype.Service;

@Service
public class studentService {
	studentrep studRepository

	}

}
